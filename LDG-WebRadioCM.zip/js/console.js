console.log("DESENVOLVIDO POR JpDevs & Álvaro")
console.log("Copyright 2020")
console.log("A cópia desse site é ilegal e poderá acarretar meios judiciais")
console.log("Level Development Group")