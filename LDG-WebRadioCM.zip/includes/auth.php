<?php
    $host = 'localhost';
    $bd = 'site1';
    $usuario = 'root';
    $senha = '';
    $key = 'LDG-04XCVBGJ-56534-ZXCVBD';
    ?>