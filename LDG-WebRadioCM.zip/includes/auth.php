<?php
    $host = 'localhost';
    $bd = 'heimeren_sitea';
    $usuario = 'heimeren_sitea';
    $senha = 'DLXjq)rUjQX!';
    $key = 'LDG-04XCVBGJ-56534-ZXCVBD';
    ?>