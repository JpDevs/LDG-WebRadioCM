# Web-Radio Content Manager
Web-Radio Content Manager é um site administravel para web-rádios que utilizam do painel de gerencialmento de shoutcast CentovaCast.

## Instalação

Crie um banco de dados e faça upload da data-base
Acesse a index da aplicação, e você será redirecionado para a página de install


## Contribuidores
Essa aplicação está sendo desenvolvida pela Level Development Group, os desenvolvedores responsáveis são:

JpDevs: Responsável pelo back-end e banco de dados.
Alvaro Eduardo: Responsável pelo front-end.
